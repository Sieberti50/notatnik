﻿using System;

namespace notatkaConsole
{
    public class Notatka
    {
        public string Tytul;
        public string Tresc;
        public bool Wazna;
        public DateTime DataDodania;

        public Notatka(string tytul, string tresc, bool wazna)
        {
            Tytul = tytul;
            Tresc = tresc;
            Wazna = wazna;
            DataDodania = DateTime.Now;
        }

        public Notatka(string tytul)
        {
            Tytul = tytul;
            Tresc = "";
            Wazna = false;
            DataDodania = DateTime.Now;
        }

        /*
         nazwa: Wypisz
         opis: Wyświetla notatkę w konsoli: linię poziomą, tytuł (z informacją o ważności), treść, datę dodania i drugą linię poziomą
         parametry: brak
         zwracany typ: brak
         autor: TWÓJ_NUMER
        */
        public void Wypisz()
        {
            Console.WriteLine("_______________________");
            if (Wazna)
            {
                Console.WriteLine("Notatka WAŻNA! " + Tytul);
            }
            else
            {
                Console.WriteLine("Notatka " + Tytul);
            }
            Console.WriteLine(Tresc);
            Console.WriteLine(DataDodania.ToString("dd.MM.yyyy HH:mm:ss"));
            Console.WriteLine("_______________________");
        }
    }
}