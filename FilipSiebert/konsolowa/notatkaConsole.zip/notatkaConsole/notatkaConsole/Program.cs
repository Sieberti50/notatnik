﻿using System;

namespace notatkaConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            Notatka pierwsza = new Notatka("tenis", "Gra z Ewą w poniedziałek", true);

            Console.WriteLine("Podaj tytuł notatki:");
            string tytul = Console.ReadLine();
            Notatka druga = new Notatka(tytul);

            pierwsza.Wypisz();
            druga.Wypisz();

            Console.ReadKey();
        }
    }
}